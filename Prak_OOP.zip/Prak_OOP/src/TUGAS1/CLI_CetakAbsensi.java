/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS1;

/**
 *
 * @author Arika Cantik
 */
public class CLI_CetakAbsensi {
    public static void main(String[] args) {
// membuat object dengan nama “mhs” dari class Mahasiswa
AbsensiMhs mhs = new AbsensiMhs();
//ketika akan menggunakan method dari class Mahasiswa maka harus menyertakan nama object
mhs.dataNIM("2118112");
mhs.dataNama("Firman Frezy Pradana");
mhs.dataKelas("Laki-laki ");
mhs.dataProdi("Teknik Informatika");
mhs.dataKeterangan("2021");

System.out.println("Kartu Tanda Mahasiswa ITN Malang");
System.out.println("------------------------------------");
System.out.println("NIM : "+ mhs.cetakNIM());
System.out.println("Nama : "+ mhs.cetakNama());
System.out.println("Kelas : "+ mhs.cetakKelas());
System.out.println("Prodi : "+ mhs.cetakProdi());
System.out.println("Keterangan : "+ mhs.cetakKeterangan());
}
    
}
