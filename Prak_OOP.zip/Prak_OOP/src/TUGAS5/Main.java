/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS5;

/**
 *
 * @author Arika Cantik
 */
public class Main {
    public static void main(String[] args) {
        // Membuat objek Mahasiswa
        Mahasiswa mahasiswa = new Mahasiswa("Rahardian Tria Alfatih", "228058");

        // Memanggil metode info dari kelas Mahasiswa
        mahasiswa.info();

        System.out.println("\n----------------\n");

        // Membuat objek Absensi
        Absensi absensi = new Absensi("Rahardian Tria Alfatih", "228058", 28);

        // Memanggil metode info dari kelas Absensi (yang sudah di-overriding)
        absensi.info();

        System.out.println("\n----------------\n");

        // Memanggil metode info(int semester) dari kelas Absensi (yang di-overload)
        absensi.info(3);
    }
}
