/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS4;

/**
 *
 * @author Arika Cantik
 */
public class Mahasiswa {

    private String nama;
    private String nim;
    private String prodi;
    private String matakuliah;
    private boolean hadir;

    public Mahasiswa(String nama, String nim, String prodi, String matakuliah) {
        this.nama = nama;
        this.nim = nim;
        this.nim = prodi;
        this.nim = matakuliah;
        this.hadir = false;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getProdi() {
        return prodi;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public String getMatakuliah() {
        return matakuliah;
    }

    public void setMatakuliah(String matakuliah) {
        this.matakuliah = matakuliah;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public boolean isHadir() {
        return hadir;
    }

    public void absen() {
        this.hadir = true;
    }

    public void absenTidakHadir() {
        this.hadir = false;
    }
}
