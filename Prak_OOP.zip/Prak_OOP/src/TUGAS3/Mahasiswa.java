/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS3;

/**
 *
 * @author Arika Cantik
 */
public class Mahasiswa extends Absensi {

    int Daftarhadir, TidakHadir, NA;

    int hasilAkhir() {
        NA = Daftarhadir - TidakHadir;
        return NA;
    }
}
