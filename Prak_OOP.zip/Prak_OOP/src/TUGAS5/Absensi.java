/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS5;

/**
 *
 * @author Arika Cantik
 */
public class Absensi extends Mahasiswa {

    private int kehadiran;

    // Konstruktor dengan parameter
    public Absensi(String nama, String nim, int kehadiran) {
        super(nama, nim);
        this.kehadiran = kehadiran;
    }

    // Getter dan setter
    public int getKehadiran() {
        return kehadiran;
    }

    public void setKehadiran(int kehadiran) {
        this.kehadiran = kehadiran;
    }

    // Overriding metode info dari kelas Mahasiswa
    @Override
    public void info() {
        super.info(); // Memanggil metode info dari kelas Mahasiswa
        System.out.println("Kehadiran: " + kehadiran + " hari");
    }

    // Metode overload untuk mencetak informasi mahasiswa dan kehadiran
    public void info(int semester) {
        info(); // Memanggil metode info yang sudah di-overriding
        System.out.println("Semester: " + semester);
    }
}
