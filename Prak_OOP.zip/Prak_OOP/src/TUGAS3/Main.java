/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS3;

/**
 *
 * @author Arika Cantik
 */


public class Main {
    public static void main(String[] args) {
       
        // Menggunakan polimorfisme dengan objek Absensi
        Absensi absensi = new Dosen("Ultramen S.KOM M.KOM", "789012", "OOP", 15, 3);

        // Memanggil metode absen() pada objek Absensi (yang sebenarnya adalah objek Dosen)
        absensi.absen();

        // Memanggil metode info() pada objek Absensi (yang sebenarnya adalah objek Dosen)
        absensi.info();
    }
}

    

