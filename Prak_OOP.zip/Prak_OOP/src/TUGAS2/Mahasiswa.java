/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS2;

/**
 *
 * @author Arika Cantik
 */
public class Mahasiswa {

    public String nama, nim, fakultas, prodi;
    public int jumlahHadir;

    //Konstruktor untuk inisialisasi objek mahasiswa
    public Mahasiswa(String nama, String nim, String fakultas, String prodi) {
        this.nama = nama;
        this.nim = nim;
        this.fakultas = fakultas;
        this.prodi = prodi;
        this.jumlahHadir = 5;
    }

    // Metode untuk melakukan absensi
    public void absen() {
        this.jumlahHadir++;
    }
    // Metode untuk mendapatkan nama mhs

    public String getNama() {
        return nama;
    }
    // Metode untuk mendapatkan nim mhs

    public String getNim() {
        return nim;
    }
    // Metode untuk mendapatkan prodi mhs

    public String getProdi() {
        return prodi;
    }
    // Metode untuk mendapatkan fakultas mhs

    public String getFakultas() {
        return fakultas;
    }
    // Metode untuk mendapatkan jumlah hadir

    public int getJumlahHadir() {
        return jumlahHadir;
    }
}
