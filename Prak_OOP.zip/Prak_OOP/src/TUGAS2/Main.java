/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS2;

/**
 *
 * @author Arika Cantik
 */
public class Main {

    public static void main(String[] args) {
        Mahasiswa abs = new Mahasiswa("Rahardian", "2218058", "Fakultas Tekonologi Industri", "S1 - Teknik Informatika");

        abs.absen(); // Mahasiswa hadir

        //mencetak
        System.out.println("ABSENSI MAHASISWA");
        System.out.println("=================================");
        System.out.println("Nama : " + abs.getNama() + "\n" + "NIM : " + abs.getNim() + "\n" + "Fakultas : " + abs.getFakultas() + "\n" + "Prodi : " + abs.getProdi() + "\n" + "Jumlah Hadir : " + abs.getJumlahHadir());

    }
}

