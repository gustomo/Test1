/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS3;

/**
 *
 * @author Arika Cantik
 */
// Kelas Dosen
public class Dosen extends Absensi {

    protected int jumlahPertemuan;
    protected int jumlahMengajar;

    public Dosen(String nama, String nip, String mk, int jumlahPertemuan, int jumlahMengajar) {
        super(nama, nip, mk);
        this.jumlahPertemuan = jumlahPertemuan;
        this.jumlahMengajar = jumlahMengajar;
    }

    @Override
    public void absen() {
        kehadiran = jumlahPertemuan - jumlahMengajar;
    }

    // Metode untuk menampilkan informasi spesifik Dosen
    public void displayInfo() {
        System.out.println("Info Dosen");
        info(); // Menggunakan polimorfisme untuk menampilkan informasi umum
        System.out.println("Jumlah Pertemuan: " + jumlahPertemuan);
        System.out.println("Jumlah Mengajar: " + jumlahMengajar);
    }
    
    // Getter untuk jumlahPertemuan
    public int getJumlahPertemuan() {
        return jumlahPertemuan;
    }

    // Getter untuk jumlahMengajar
    public int getJumlahMengajar() {
        return jumlahMengajar;
    }

    // Getter untuk kehadiran
    public int getKehadiran() {
        return kehadiran;
    }

    // Setter untuk jumlahPertemuan
    public void setJumlahPertemuan(int jumlahPertemuan) {
        this.jumlahPertemuan = jumlahPertemuan;
    }

    // Setter untuk jumlahMengajar
    public void setJumlahMengajar(int jumlahMengajar) {
        this.jumlahMengajar = jumlahMengajar;
    }
}


   
