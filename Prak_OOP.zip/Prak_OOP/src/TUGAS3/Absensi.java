/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS3;

/**
 *
 * @author Arika Cantik
 */
// Kelas Absensi
public abstract class Absensi {

    protected String nama;
    protected String nip;
    protected String Mk;
    protected int kehadiran;

    public Absensi(String nama, String nip, String Mk) {
        this.nama = nama;
        this.nip = nip;
        this.Mk = Mk;
        this.kehadiran = 0;
    }

    public abstract void absen();

    // Metode untuk menampilkan informasi umum
    public void info() {
        System.out.println("Info Absensi");
        System.out.println("Nama Dosen: " + nama);
        System.out.println("NIP: " + nip);
        System.out.println("Mata Kuliah: " + Mk);
        System.out.println("Kehadiran: " + kehadiran);
    }
}

