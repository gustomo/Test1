/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS4;

/**
 *
 * @author Arika Cantik
 */
public class Main {

    public static void main(String[] args) {
        Mahasiswa mahasiswa1 = new Mahasiswa("Rahardian", "OOP", "Informatika", "2218058");
        Kelas kelas = new Kelas("Informatika A");
        kelas.tambahMahasiswa(mahasiswa1);
        kelas.absenMahasiswa(mahasiswa1);
        System.out.println("Absensi Mahasiswa" + "\n");
        System.out.println("=============================" + "\n");
        System.out.println("Nama             : " + mahasiswa1.getNama() + "\n" + "Nim              : " + mahasiswa1.getNim() + "\n" + "Status Kehadiran : " + (mahasiswa1.isHadir() ? "Hadir" : "Tidak Hadir") + "\n");
        System.out.println("=============================");
    }
}


