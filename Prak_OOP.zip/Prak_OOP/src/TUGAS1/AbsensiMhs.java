/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS1;

/**
 *
 * @author Arika Cantik
 */
public class AbsensiMhs {
    private String nim;
    private String nama;
    private String prodi;
    private String kelas;
    private String keterangan;

    public void dataNIM(String nim) {
        this.nim = nim;
    }

    public void dataNama(String nama) {
        this.nama = nama;
    }

    public void dataProdi(String prodi) {
        this.prodi = prodi;
    }

    public void dataKelas(String kelas) {
        this.kelas = kelas;
    }

    public void dataKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String cetakNIM() {
        return nim;
    }

    public String cetakNama() {
        return nama;
    }

    public String cetakProdi() {
        return prodi;
    }

    public String cetakKelas() {
        return kelas;
    }

    public String cetakKeterangan() {
        return keterangan;
    }
}

