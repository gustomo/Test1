/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS4;

/**
 *
 * @author Arika Cantik
 */
import java.util.ArrayList;
import java.util.List;

public class Kelas {

    private String namaKelas;
    private List<Mahasiswa> daftarMahasiswa;

    public Kelas(String namaKelas) {
        this.namaKelas = namaKelas;
        this.daftarMahasiswa = new ArrayList<>();
    }

    public String getNamaKelas() {
        return namaKelas;
    }

    public void setNamaKelas(String namaKelas) {
        this.namaKelas = namaKelas;
    }

    public void tambahMahasiswa(Mahasiswa mahasiswa) {
        daftarMahasiswa.add(mahasiswa);
    }

    public void absenMahasiswa(Mahasiswa mahasiswa) {
        if (daftarMahasiswa.contains(mahasiswa)) {
            mahasiswa.absen();
        } else {
            System.out.println("Mahasiswa tidak terdaftar dalam kelas ini.");
        }
    }
}

